package unibo.webRobot22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebRobot22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
