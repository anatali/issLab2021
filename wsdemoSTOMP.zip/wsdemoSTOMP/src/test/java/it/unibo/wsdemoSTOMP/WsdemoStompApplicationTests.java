package it.unibo.wsdemoSTOMP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsdemoStompApplicationTests {

	@Test
	void contextLoads() {
	}

}
