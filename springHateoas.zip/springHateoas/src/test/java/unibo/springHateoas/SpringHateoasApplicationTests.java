package unibo.springHateoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHateoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
